const User = require("../model/usermodel");
const bcrypt = require('bcryptjs');
const GenerateToken = require("../utils/GenerateToken");
const userValidationSchema = require('../validations/userValidation'); 
const loginValidationSchema = require('../validations/loginValidation');



module.exports.registercontroller = async (req, res) => {
  try {
    // ✅ Joi Validation
    const { error } = userValidationSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ message: error.details[0].message });
    }

    const { name, age, phone, password } = req.body;

    // ✅ Check if user already exists
    const existingUser = await User.findOne({ phone });
    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }

    // ✅ Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // ✅ Save user
    const newUser = new User({ name, age, phone, password: hashedPassword });
    await newUser.save();

    // ✅ Generate token and set cookie
    const token = GenerateToken(phone);
    res.cookie("token", token, {
      httpOnly: true,
      secure: false, // use true in production with HTTPS
      maxAge: 60 * 60 * 1000,
      sameSite: "Lax"
    });

    return res.status(201).json({ message: "User registered successfully" });

  } catch (error) {
    console.error("Error in registercontroller:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

module.exports.logincontroller = async (req, res) => {
  try {
    // ✅ Validate request body with Joi
    const { error } = loginValidationSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ message: error.details[0].message });
    }

    const { phone, password } = req.body;

    // ✅ Find the user by phone number
    const user = await User.findOne({ phone });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // ✅ Compare the password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid Password" });
    }

    // ✅ Generate token and set cookie
    const token = GenerateToken(user.phone);
    res.cookie("token", token, {
      httpOnly: true,
      secure: false, // set to true in production with HTTPS
      maxAge: 60 * 60 * 1000,
    });

    return res.status(200).json({ message: "Login successful", user });

  } catch (error) {
    console.error("Error in logincontroller:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};


module.exports.logout = async (req, res) => {
    try {
        // Clear the token cookie
        
        res.clearCookie("token");
        return res.status(200).json({ message: "Logout successful" });
    } catch (error) {
        console.error("Error in logout:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
}

module.exports.fetchProfile = async (req, res) => {
  try {
    const phone = req.phone;
    

    const user = await User.findOne({ phone });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    return res.status(200).json({ message: "fetch successfully", user });

  } catch (error) {
    console.error("Error in fetchProfile:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

module.exports.profileedit = async (req, res) => {
    try {
        const phone = req.phone;
        const { name, age } = req.body;

        // Find the user by phone number
        const user = await User.findOne({ phone });
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        // Update user profile
        user.name = name || user.name;
        user.age = age || user.age;

        // Save the updated user
        await user.save();

        return res.status(200).json({ message: "Profile updated successfully", user });
    } catch (error) {
        console.error("Error in profileedit:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
}