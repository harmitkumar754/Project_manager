const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    name: {
        type: String,
        
    },
    age: {
        type: Number,
    

    },
    phone: {
        type: Number,
        
    },
    password: {
        type: String,
    
    }
}, { timestamps: true });

module.exports=mongoose.model('users', userSchema);