import React from 'react';

function About() {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center px-6">
      <div className="bg-white p-8 rounded shadow-md max-w-2xl w-full">
        <h1 className="text-3xl font-bold mb-4 text-center">About Us</h1>
        <p className="text-gray-700 leading-relaxed">
          Welcome to <span className="font-semibold text-blue-600">MyApp</span>!
          We are a team of passionate developers and designers building simple and effective web solutions.
        </p>
        <p className="text-gray-700 mt-4 leading-relaxed">
          Our goal is to provide clean, intuitive, and responsive interfaces for modern web applications.
          Whether you’re a business or an individual, we’re here to help you bring your ideas to life.
        </p>
        <p className="text-gray-700 mt-4 leading-relaxed">
          Thank you for visiting our site. We hope you enjoy using our application as much as we enjoyed building it!
        </p>
      </div>
    </div>
  );
}

export default About;
