// import { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
// import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './home'
import Header from './Header'
import Footer from './Footer'
import About from './About'
import Profile from './Profile'
import Login from './Login'
import Register from './Register'
  import { ToastContainer } from 'react-toastify';
import ProtectedRoute from './ProtectedRoute'

function App() {
  

  return (
  
     <>
     <BrowserRouter>
     <Header />
      <ToastContainer autoClose={2000} />
     <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/" element={<ProtectedRoute><Profile/></ProtectedRoute>} />
        <Route path="/login" element={<Login/>} />
        <Route path="/Register" element={<Register/>} />
     </Routes>
     <Footer />
      </BrowserRouter>
     </>
  )
}

export default App
