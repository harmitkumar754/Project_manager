import React from 'react'

function home() {
  
  return (
    <div className='w-full h-screen flex flex-col items-center justify-center bg-gray-100'>
        <h1 className='text-4xl font-bold mb-4'>Welcome to MyApp</h1>
       
        
    </div>
  )
}

export default home